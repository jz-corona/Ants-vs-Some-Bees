//
// Created by Anthony on 11/4/2020.
//

#include "Ant_Bodyguard.h"

void Ant_Bodyguard::action() {
}

Ant_Bodyguard::Ant_Bodyguard() {
    myID = ANT_BODYGUARD;
    armor = 2;
}

std::string Ant_Bodyguard::print() {
    return "Bodyguard Armor: " + to_string(armor);
}

Ant_Bodyguard::Ant_Bodyguard(int pos) {
    myID = Bug::bugID::ANT_BODYGUARD;
    armor = 2;
    position = pos;
    BugBoard::bugBoard[pos].push_back(this);
    innerpos = BugBoard::bugBoard[pos].size()-1;
}

void Ant_Bodyguard::die() {
    BugBoard::bugBoard[position].erase(BugBoard::bugBoard[position].begin() + innerpos);
    for(int i = 0; i < BugBoard::bugBoard[position].size(); i++) {
        BugBoard::bugBoard[position][i]->innerpos--;
    }
}