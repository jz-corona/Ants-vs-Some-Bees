//
// Created by Anthony on 11/2/2020.
//
#include "Ant.h"

Ant::Ant() {
    myID = ANT;
}

Ant::~Ant() {
}

void Ant::die(){

}

