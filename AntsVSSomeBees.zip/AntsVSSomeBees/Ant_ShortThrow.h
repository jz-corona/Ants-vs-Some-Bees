//
// Created by Anthony on 11/4/2020.
//

#ifndef ANTSVSSOMEBEES_ANT_SHORTTHROW_H
#define ANTSVSSOMEBEES_ANT_SHORTTHROW_H
#include "Ant.h"
#include "BugBoard.h"

class Ant_ShortThrow : public Ant{
    ~Ant_ShortThrow();
    Ant_ShortThrow & operator=(Ant_ShortThrow & right);
    void die() override ;
    void action();

    std::string print() override;
public:
    Ant_ShortThrow();
    Ant_ShortThrow(int pos);
    static const int cost = 3;
};

#endif //ANTSVSSOMEBEES_ANT_SHORTTHROW_H
