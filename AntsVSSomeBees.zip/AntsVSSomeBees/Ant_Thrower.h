//
// Created by Anthony on 11/2/2020.
//

#ifndef ANTSVSSOMEBEES_ANT_THROWER_H
#define ANTSVSSOMEBEES_ANT_THROWER_H

#include <iostream>
#include "Ant.h "
#include "BugBoard.h"

class Ant_Thrower : public Ant{
    ~Ant_Thrower();
    Ant_Thrower & operator=(Ant_Thrower & right);
    void action();
    void die() override ;
    std::string print() override;
public:
    Ant_Thrower();
    Ant_Thrower(int pos);
    static const int cost = 3;
};

#endif //ANTSVSSOMEBEES_ANT_THROWER_H
