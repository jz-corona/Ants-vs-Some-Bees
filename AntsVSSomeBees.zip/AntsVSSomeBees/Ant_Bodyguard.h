//
// Created by Anthony on 11/2/2020.
//

#ifndef ANTSVSSOMEBEES_ANT_BODYGUARD_H
#define ANTSVSSOMEBEES_ANT_BODYGUARD_H
class BugBoard;
#include "BugBoard.h"


class Ant_Bodyguard : public Ant{
    ~Ant_Bodyguard();
    Ant_Bodyguard & operator=(Ant_Bodyguard & right);
    void die() override ;
    void action() override;
    std::string print() override;

public:
    Ant_Bodyguard();
    Ant_Bodyguard(int pos);
    static const int cost = 4;
};


#endif //ANTSVSSOMEBEES_ANT_BODYGUARD_H
