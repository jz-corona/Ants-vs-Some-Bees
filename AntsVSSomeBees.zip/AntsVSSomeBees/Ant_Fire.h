//
// Created by Anthony on 11/4/2020.
//

#ifndef ANTSVSSOMEBEES_ANT_FIRE_H
#define ANTSVSSOMEBEES_ANT_FIRE_H

#include "Ant.h "
#include "AntsVsSomeBees.h"

class Ant_Fire : public Ant{
    ~Ant_Fire();
    Ant_Fire & operator=(Ant_Fire & right);

    void die() override ;

    virtual void action();
    std::string print() override;

public:
    Ant_Fire();
    Ant_Fire(int pos);

    static const int cost = 4;
};


#endif //ANTSVSSOMEBEES_ANT_FIRE_H
