//
// Created by Anthony on 11/4/2020.
//

#include "Ant_Wall.h"

Ant_Wall::Ant_Wall() {
    myID = ANT_WALL;
    armor = 4;
}

void Ant_Wall::action() {
}

std::string Ant_Wall::print() {
    return "Wall Armor: " + to_string(armor);
}

Ant_Wall::Ant_Wall(int pos) {
    myID = Bug::bugID::ANT_WALL;
    armor = 4;
    position = pos;
    BugBoard::bugBoard[pos].push_back(this);
    innerpos = BugBoard::bugBoard[pos].size()-1;
}

void Ant_Wall::die() {
    BugBoard::bugBoard[position].erase(BugBoard::bugBoard[position].begin() + innerpos);
    for(int i = 0; i < BugBoard::bugBoard[position].size(); i++) {
        BugBoard::bugBoard[position][i]->innerpos--; //lower the following values if dead individual wasn't the end of the mf list
    }
}
