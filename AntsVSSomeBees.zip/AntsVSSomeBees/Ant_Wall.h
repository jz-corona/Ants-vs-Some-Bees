//
// Created by Anthony on 11/2/2020.
//

#ifndef ANTSVSSOMEBEES_ANT_WALL_H
#define ANTSVSSOMEBEES_ANT_WALL_H
#include "Ant.h"
#include "BugBoard.h"

class Ant_Wall : public Ant{
    void die() override ;
    ~Ant_Wall();
    Ant_Wall & operator=(Ant_Wall & right);
    void action();
    std::string print() override;
public:
    Ant_Wall();
    Ant_Wall(int pos);
    static const int cost = 4;
};

#endif //ANTSVSSOMEBEES_ANT_WALL_H
