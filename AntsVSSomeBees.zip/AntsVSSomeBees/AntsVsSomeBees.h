//
// Created by Anthony on 11/2/2020.
//

#ifndef ANTSVSSOMEBEES_ANTSVSBEES_H
#define ANTSVSSOMEBEES_ANTSVSBEES_H
#include "Bug.h"
#include "BugBoard.h"

class AntsVsSomeBees {

private:
    bool turn();
    void board();
    void runActions();
    void options();
    bool isGameOver();
    bool placeAnt(int a, int b, Bug *c);
    void makeANewBugOfTypeAt(Bug::bugID bugType, int position);
    int input();
public:
    void runGame();
    ~AntsVsSomeBees();
    AntsVsSomeBees();
    AntsVsSomeBees(AntsVsSomeBees & in);
    AntsVsSomeBees & operator=(AntsVsSomeBees & right);
};


#endif //ANTSVSSOMEBEES_ANTSVSSOMEBEES_H
