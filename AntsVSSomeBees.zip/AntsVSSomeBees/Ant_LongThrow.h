//
// Created by Anthony on 11/4/2020.
//

#ifndef ANTSVSSOMEBEES_ANT_LONGTHROW_H
#define ANTSVSSOMEBEES_ANT_LONGTHROW_H

#include "Ant.h"
#include "BugBoard.h"

class Ant_LongThrow : public Ant{
    ~Ant_LongThrow();
    Ant_LongThrow & operator=(Ant_LongThrow & right);

    void die() override ;
    void action();

    std::string print() override;

public:
    Ant_LongThrow();
    Ant_LongThrow(int pos);
    static const int cost = 3;
};


#endif //ANTSVSSOMEBEES_ANT_LONGTHROW_H
