#include <iostream>
#include "AntsVsSomeBees.h"

using namespace std;

void runTests(){

}

int main() {
    AntsVsSomeBees *a = new AntsVsSomeBees();
    a->runGame();
}