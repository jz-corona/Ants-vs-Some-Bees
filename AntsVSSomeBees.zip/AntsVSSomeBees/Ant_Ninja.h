//
// Created by Anthony on 11/4/2020.
//

#ifndef ANTSVSSOMEBEES_ANT_NINJA_H
#define ANTSVSSOMEBEES_ANT_NINJA_H


#include "Ant.h"
#include "BugBoard.h"

class Ant_Ninja : public Ant{
    ~Ant_Ninja();
    Ant_Ninja & operator=(Ant_Ninja & right);

    void die() override ;
    void action();

    std::string print() override;
public:
    Ant_Ninja();
    Ant_Ninja(int pos);
    static const int cost = 6;
};


#endif//ANTSVSSOMEBEES_ANT_NINJA_H
