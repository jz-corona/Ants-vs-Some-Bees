WELCOME TO ANTS VS BEES
You lead the ants against waves of bees.
Each turn 3 bees will be placed at the far side of the board. Each turn you can place an ant unit if you have enough food.
Place your forces strategically until all the bees are dead or the bees reacdh your queen

Harvester cost:2 armor:1      -gives the colony 1 food each turn
Thrower cost:4 armor:1       -will attack a single bee on its own square
Fire Ant cost:4 armor:1      -Will sacrifice itself to kill bees on its own square
Long Thrower cost:3 armor:1  - does damage to one enemy that is at least 4 squares away
Short Thrower cost:3 armor:1 - does damage within 2 squares of space
Wall Ant: cost:4 armor:4      - keeps bees from moving past //If wall is destroyed and three bees are on the same space, game will crash
Ninja Ant: cost:6 armor:1     - cannot be hurt by bees and does 1 damage to a bee on same space
Bodyguard Ant: cost:4 armor:2 - does 0 damage, but can be placed wiht another ant to protect them //needs to be placed before the other ant