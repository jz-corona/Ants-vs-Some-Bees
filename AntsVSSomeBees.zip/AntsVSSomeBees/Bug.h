//
// Created by Anthony on 11/4/2020.
//

#ifndef ANTSVSSOMEBEES_BUG_H
#define ANTSVSSOMEBEES_BUG_H


class AntsVSSomeBees;
class BugBoard;

//class Bug;
//#include "BugBoard.h"

#include <iostream>
#include "string"
#include "vector"

class Bug {
public:
    int armor = -1;
    int position = -1;
    int innerpos = -1;
    enum bugID{ANT, BEE, BUG, ANT_BODYGUARD, ANT_FIRE, ANT_HARVESTER, ANT_LONGTHROW, ANT_NINJA, ANT_SHORTTHROW, ANT_THROWER, ANT_WALL};
    enum bugID myID;
    Bug();
    virtual std::string print();
    virtual void die();
    virtual void action(){};
    virtual void takeDamage(int dam);
    virtual void moveForward(){};
};


#endif //ANTSVSSOMEBEES_BUG_H
