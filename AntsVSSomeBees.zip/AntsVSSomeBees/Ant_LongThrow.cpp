//
// Created by Anthony on 11/4/2020.
//

#include "Ant_LongThrow.h"
#include "BugBoard.h"

void Ant_LongThrow::action() {

    int after, before;
    after = position + 4;
    before = position -4;
    bool hitOne = false;
    for(int i = after; i < BugBoard::boardSize; i++){
        for(int g = 0 ; g < BugBoard::bugBoard[i].size(); g++){
            if(BugBoard::bugBoard[i][g]->myID == Bug::bugID::BEE) {
                BugBoard::bugBoard[i][g]->takeDamage(1);
                hitOne = true;
                break;
            }
        }
        if(hitOne) break;
    }
    hitOne = false;
    for(int i = 0; i <= before; i++){
        for(int g = 0 ; g < BugBoard::bugBoard[i].size(); g++){
            if(BugBoard::bugBoard[i][g]->myID == Bug::bugID::BEE){
                BugBoard::bugBoard[i][g]->takeDamage(1);
                hitOne = true;
                break;
            }
        }
        if(hitOne)break;
    }
}

Ant_LongThrow::Ant_LongThrow() {
    myID = Bug::bugID::ANT_LONGTHROW;
}

std::string Ant_LongThrow::print() {
    return "Longthrower" ;
}

Ant_LongThrow::Ant_LongThrow(int pos) {
    myID = Bug::bugID::ANT_LONGTHROW;
    position = pos;
    BugBoard::bugBoard[pos].push_back(this);
    innerpos = BugBoard::bugBoard[pos].size()-1;
}

void Ant_LongThrow::die() {
    BugBoard::bugBoard[position].erase(BugBoard::bugBoard[position].begin() + innerpos);
    for(int i = 0; i < BugBoard::bugBoard[position].size(); i++) {
        BugBoard::bugBoard[position][i]->innerpos--;
    }
}
