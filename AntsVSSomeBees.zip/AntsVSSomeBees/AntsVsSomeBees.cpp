//
// Created by Anthony on 11/2/2020.
//

#include <iostream>

#include "AntsVsSomeBees.h"

using namespace std;

void AntsVsSomeBees::runGame(){
    cout << "\n\n\t\tPlease read the ReadMe file for instructions.";
    while(!turn());
}

bool AntsVsSomeBees::turn() {
    new Bee(BugBoard::boardSize-1);
    cout << "\n\tFood: " << BugBoard::antFood
         << "\n\tYour turn.";
    board();
    options();
    runActions();
    return isGameOver();
}

void AntsVsSomeBees::board() {
    for(int i = 0 ; i < BugBoard::bugBoard.size(); i++){
        cout << "Row " << i << ":\t";
        vector<Bug*> a = BugBoard::bugBoard[i];
        for(int g = 0; g < a.size(); g++){
            cout << a[g]->print() << " ";
        }
        cout << "\n";
    }
}

void AntsVsSomeBees::runActions() {
    cout << "\n\n################################\n";
    for(int i = 0 ; i < BugBoard::boardSize; i++){
        vector<Bug*> a = BugBoard::bugBoard[i];
        for(int g = 0; g < a.size(); g++){
            a[g]->action();
        }
    }
    for(int i = 0 ; i < BugBoard::boardSize; i++){
        vector<Bug*> a = BugBoard::bugBoard[i];
        for(int g = 0; g < a.size(); g++){
            a[g]->moveForward();
        }
    }
    cout << "\n################################\n";
}

void AntsVsSomeBees::options() {
    cout << "\n\tChoose your action - 0: Skip Turn"
            "\n\t1: Harvester  2: Thrower  3: Fire Ant 4: LongThrower "
            "\n\t5: ShortThrower  6: Wall 7: Ninja  8: Bodyguard  \n";
    switch(int unit = input()){
        case 0: default:
            break;
        case 1: case 2: case 3: case 4: case 5: case 6: case 7: case 8: //hmm
            while(true) {
                cout << "\nPlaced on which row? Position: \n";
                int b = input();
                Bug *c = BugBoard::isAntHere(b);
                if (c != nullptr && c->myID != Bug::ANT_BODYGUARD && unit != 6) {
                    cout << "There's another ant here. Pick another row";
                }else if(b < 0 || b > BugBoard::boardSize){
                    break;
                }else{
                    if(placeAnt(unit, b, c)) {
                        cout << "\nNot enough food\n";
                    }
                    break;
                }
            }
            break;
    }
}

bool AntsVsSomeBees::placeAnt(int a, int b, Bug *c){
    bool tooExpensive = false;
    switch(a){
        case 1: if(Ant_Harvester::cost < BugBoard::antFood){ BugBoard::antFood -= Ant_Harvester::cost; makeANewBugOfTypeAt(Bug::bugID::ANT_HARVESTER, b); return tooExpensive;}else{tooExpensive = true; return tooExpensive;}
        case 2: if(Ant_Thrower::cost < BugBoard::antFood){ BugBoard::antFood -= Ant_Thrower::cost;makeANewBugOfTypeAt(Bug::bugID::ANT_THROWER, b); return tooExpensive;}else{tooExpensive = true; return tooExpensive;}
        case 3: if(Ant_Fire::cost < BugBoard::antFood){ BugBoard::antFood -= Ant_Fire::cost;makeANewBugOfTypeAt(Bug::bugID::ANT_FIRE, b); return tooExpensive;}else{tooExpensive = true; return tooExpensive;}
        case 4: if(Ant_LongThrow::cost < BugBoard::antFood){ BugBoard::antFood -= Ant_LongThrow::cost;makeANewBugOfTypeAt(Bug::bugID::ANT_LONGTHROW, b); return tooExpensive;}else{tooExpensive = true; return tooExpensive;}
        case 5: if(Ant_ShortThrow::cost < BugBoard::antFood){ BugBoard::antFood -= Ant_ShortThrow::cost;makeANewBugOfTypeAt(Bug::bugID::ANT_SHORTTHROW, b); return tooExpensive;}else{tooExpensive = true; return tooExpensive;}
        case 6: if(Ant_Wall::cost < BugBoard::antFood){ BugBoard::antFood -= Ant_Wall::cost;makeANewBugOfTypeAt(Bug::bugID::ANT_WALL, b); return tooExpensive;}else{tooExpensive = true; return tooExpensive;}
        case 7: if(Ant_Ninja::cost < BugBoard::antFood){BugBoard::antFood -= Ant_Ninja::cost;makeANewBugOfTypeAt(Bug::bugID::ANT_NINJA, b);return tooExpensive;}else{tooExpensive = true; return tooExpensive;}
        case 8: if(c != nullptr && c->myID == Bug::ANT_BODYGUARD){cout << "\nCan't have two bodyguards in one row\n";return tooExpensive;
            }else if(Ant_Bodyguard::cost < BugBoard::antFood){BugBoard::antFood -= Ant_Bodyguard::cost;makeANewBugOfTypeAt(Bug::bugID::ANT_BODYGUARD, b);return tooExpensive;}else{ tooExpensive = true; return tooExpensive;}
        default: return tooExpensive;
    }
}

void AntsVsSomeBees::makeANewBugOfTypeAt(Bug::bugID bugType, int pos) {
    switch(bugType){
        case Bug::bugID::ANT_HARVESTER:
            new Ant_Harvester(pos);
            break;
        case Bug::bugID::ANT_THROWER:
            new Ant_Thrower(pos);
            break;
        case Bug::bugID::ANT_FIRE:
            new Ant_Fire(pos);
            break;
        case Bug::bugID::ANT_LONGTHROW:
            new Ant_LongThrow(pos);
            break;
        case Bug::bugID::ANT_SHORTTHROW:
            new Ant_ShortThrow(pos);
            break;
        case Bug::bugID::ANT_WALL:
            new Ant_Wall(pos);
            break;
        case Bug::bugID::ANT_NINJA:
            new Ant_Ninja(pos);
            break;
        case Bug::bugID::ANT_BODYGUARD:
            new Ant_Bodyguard(pos);
            break;
        case Bug::bugID::BEE:
            new Bee(pos);
            break;
        default: break;
    }
}

bool AntsVsSomeBees::isGameOver() {
    for(int i = 0 ; i < BugBoard::bugBoard[0].size(); i++){
        if(! BugBoard::bugBoard[0][i]->myID == Bug::bugID::BEE ) return false;
    }
    if(BugBoard::bugBoard[0].size() > 0 && BugBoard::bugBoard[0][0]->myID == Bug::bugID::BEE){
        cout << "\nYour colony has been destroyed!";
        return true;
    }
    bool isBees = false;
    for(int i = 0 ; i < BugBoard::boardSize; i++){
        if(BugBoard::isBeeHere(i) != nullptr){
            isBees = true;
            break;
        }
    }
    if(!isBees){
        cout << "\nThe bees have been eliminated!";
        return true;
    }
    return false;
}

AntsVsSomeBees::~AntsVsSomeBees() {
}

AntsVsSomeBees::AntsVsSomeBees() {
    BugBoard();
}

AntsVsSomeBees::AntsVsSomeBees(AntsVsSomeBees &in) {
}

AntsVsSomeBees &AntsVsSomeBees::operator=(AntsVsSomeBees &right) {
    if(this == &right) return *this;
    AntsVsSomeBees * sv = new AntsVsSomeBees(right);
    return *sv;
}

int AntsVsSomeBees::input() {
    string s;
    cout << ">>>";
    getline(cin , s);
    string nums = "";
    for( int i = 0 ; i < s.length(); i++){
        if(isdigit(s[i])) nums += s[i];
    }
    if(nums.length() < 1) return -1;
    int toRet = stoi(nums);
    return toRet;
}
