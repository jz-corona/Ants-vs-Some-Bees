//
// Created by Anthony on 11/4/2020.
//

#ifndef ANTSVSSOMEBEES_BEE_H
#define ANTSVSSOMEBEES_BEE_H



class BugBoard;
class Bee;

#include "Bug.h"
#include "BugBoard.h"

class Bee : public Bug{
public:
    Bee();
    Bee(int position);
    void die() override;
    void action() override;
    void moveForward() override;

    std::string print() override;
};



#endif //ANTSVSSOMEBEES_BEE_H
