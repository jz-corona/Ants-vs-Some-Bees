//
// Created by Anthony on 11/4/2020.
//

#ifndef ANTSVSSOMEBEES_ANT_H
#define ANTSVSSOMEBEES_ANT_H

class BugBoard;
class Ant;
#include "Bug.h"
class Ant : public Bug {
public:
    void die() override;
    void action() override{};
    void moveForward() override{};
    Ant();
    ~Ant();
    Ant & operator=(Ant & right);
};
#endif //ANTSVSSOMEBEES_ANT_H
