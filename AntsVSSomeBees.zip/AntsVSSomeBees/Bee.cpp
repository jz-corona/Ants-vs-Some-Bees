//
// Created by Anthony on 11/4/2020.
//

#include "Bee.h"

Bee::Bee() {
    myID = Bug::bugID::BEE;
    armor = 3;
    position = -1;
    innerpos = -1;
}

Bee::Bee(int pos){
    myID = Bug::bugID::BEE;
    armor = 3;
    position = pos;
    BugBoard::bugBoard[pos].push_back(this);
    innerpos = BugBoard::bugBoard[pos].size()-1;
}

std::string Bee::print() {
    return "Bee Armor: " + to_string(armor) + "/3";
}

void Bee::action() {
    vector<Bug*> a = BugBoard::bugBoard[position];
    for(int i = 0; i < a.size(); i++){
        if(a[i]->myID == Bug::bugID::ANT_BODYGUARD){
            a[i]->takeDamage(1);
            return;
        }
    }
    for(int i = 0; i < a.size(); i++){
        if(a[i]->myID != Bug::bugID::BEE && a[i]->myID != Bug::bugID::ANT_NINJA){
            a[i]->takeDamage(1);
            return;
        }
    }
}
void Bee::die() {
    vector<Bug*> b = BugBoard::bugBoard[position];
    BugBoard::bugBoard[position].erase(BugBoard::bugBoard[position].begin() + innerpos);
    for(int i = 0; i < BugBoard::bugBoard[position].size(); i++) {
        BugBoard::bugBoard[position][i]->innerpos--;
    }
}
void Bee::moveForward() {
    if(position == 0) return;
    for(int i = 0; i < BugBoard::bugBoard[position].size(); i++){
        if(BugBoard::bugBoard[position][i]->myID != Bug::bugID::BEE && BugBoard::bugBoard[position][i]->myID != Bug::bugID::ANT_NINJA){
            return; //then can't move forward
        }
    }
    BugBoard::bugBoard[position-1].push_back(this);
    swap(BugBoard::bugBoard[position][innerpos], BugBoard::bugBoard[position][BugBoard::bugBoard[position].size()-1]);
    BugBoard::bugBoard[position][innerpos]->innerpos = position-1;
    BugBoard::bugBoard[position].resize(BugBoard::bugBoard[position].size()-1);
    position -= 1; // update to new position
    innerpos = BugBoard::bugBoard[position].size()-1;
}




