//
// Created by Anthony on 11/4/2020.
//

#include "Ant_Harvester.h"

void Ant_Harvester::action() {
    BugBoard::antFood += 1;
}

Ant_Harvester::Ant_Harvester() {
    myID = Bug::bugID::ANT_HARVESTER;
}


Ant_Harvester::Ant_Harvester(int pos) {
    myID = Bug::bugID::ANT_HARVESTER;
    position = pos;
    BugBoard::bugBoard[pos].push_back(this);
    innerpos = BugBoard::bugBoard[pos].size()-1;
}

void Ant_Harvester::die() {
    BugBoard::bugBoard[position].erase(BugBoard::bugBoard[position].begin() + innerpos);
    for(int i = 0; i < BugBoard::bugBoard[position].size(); i++) {
        BugBoard::bugBoard[position][i]->innerpos--;
    }
}

std::string Ant_Harvester::print() {
    return "Harvester";
}